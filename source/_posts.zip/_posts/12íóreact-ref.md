---
title: 12、ref的用法
date: now
tags:
  - React标签
categories:
  - React
---

```js
ref的用法;
```
